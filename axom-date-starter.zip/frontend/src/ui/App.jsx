import React, { useEffect, useState } from "react";

const API = import.meta.env.VITE_API || "http://localhost:5050";

function useAuth(){
  const [token, setTokenState] = useState(localStorage.getItem("token") || "");
  const setToken = (t)=>{
    setTokenState(t);
    if(t) localStorage.setItem("token", t);
    else localStorage.removeItem("token");
  };
  return { token, setToken };
}

function Assamese({ children }){ return <>{children}</>; }

function Login({ setToken }){
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = async (e)=>{
    e.preventDefault();
    setError("");
    const r = await fetch(`${API}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await r.json();
    if(!r.ok){ setError(data.error || "Login failed"); return; }
    setToken(data.token);
  };

  return (
    <div style={{maxWidth:420, margin:"40px auto"}}>
      <h2>প্ৰৱেশ কৰক (Login)</h2>
      <form onSubmit={submit}>
        <label>ই-মেইল</label>
        <input value={email} onChange={(e)=>setEmail(e.target.value)} required style={{width:"100%", padding:8}} />
        <label>গুপ্তশব্দ</label>
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required style={{width:"100%", padding:8}} />
        {error && <p>{error}</p>}
        <button type="submit" style={{marginTop:12}}>প্ৰৱেশ</button>
      </form>
    </div>
  );
}

function Register(){
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [done, setDone] = useState(false);
  const [err, setErr] = useState("");

  const submit = async (e)=>{
    e.preventDefault();
    setErr("");
    const r = await fetch(`${API}/api/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password })
    });
    const data = await r.json();
    if(!r.ok){ setErr(data.error || "Failed"); return; }
    setDone(true);
  };

  if(done) return <p>নিবন্ধন সফল। এতিয়া লগইন কৰক।</p>;

  return (
    <div style={{maxWidth:420, margin:"40px auto"}}>
      <h2>নিবন্ধন (Register)</h2>
      <form onSubmit={submit}>
        <label>নাম</label>
        <input value={name} onChange={(e)=>setName(e.target.value)} required style={{width:"100%", padding:8}} />
        <label>ই-মেইল</label>
        <input value={email} onChange={(e)=>setEmail(e.target.value)} required style={{width:"100%", padding:8}} />
        <label>গুপ্তশব্দ</label>
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required style={{width:"100%", padding:8}} />
        {err && <p>{err}</p>}
        <button type="submit" style={{marginTop:12}}>একাউণ্ট বনাওক</button>
      </form>
    </div>
  );
}

function Profile({ token }){
  const [me, setMe] = useState(null);
  const [bio, setBio] = useState("");
  const [city, setCity] = useState("");

  useEffect(()=>{
    (async ()=>{
      const r = await fetch(`${API}/api/profile/me`, { headers: { Authorization: `Bearer ${token}` }});
      const data = await r.json();
      setMe(data.user);
      setBio(data.user?.bio||"");
      setCity(data.user?.city||"");
    })();
  }, [token]);

  const save = async ()=>{
    const r = await fetch(`${API}/api/profile/update`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ name: me.name, gender: me.gender, dob: me.dob, bio, city })
    });
    const data = await r.json();
    setMe(data.user);
    alert("সাঁচি ৰখা হৈছিল!");
  };

  if(!me) return <p>লোড হৈ আছে…</p>;
  return (
    <div style={{maxWidth:600, margin:"20px auto"}}>
      <h2>মোৰ প্ৰ'ফাইল</h2>
      <p><b>নাম:</b> {me.name}</p>
      <label>জীৱনী</label>
      <textarea value={bio} onChange={(e)=>setBio(e.target.value)} style={{width:"100%", minHeight:100}} />
      <label>চহৰ</label>
      <input value={city} onChange={(e)=>setCity(e.target.value)} style={{width:"100%", padding:8}} />
      <button onClick={save} style={{marginTop:12}}>আপডেট কৰক</button>
    </div>
  );
}

function Browse({ token }){
  const [users, setUsers] = useState([]);
  useEffect(()=>{
    (async ()=>{
      const r = await fetch(`${API}/api/browse`, { headers: { Authorization: `Bearer ${token}` }});
      const data = await r.json();
      setUsers(data.users || []);
    })();
  }, [token]);

  const like = async (id)=>{
    const r = await fetch(`${API}/api/like/${id}`, { method:"POST", headers: { Authorization: `Bearer ${token}` }});
    const data = await r.json();
    alert(data.matched ? "মেচ হল!" : "পছন্দ কৰিছে");
  };

  return (
    <div style={{maxWidth:900, margin:"20px auto"}}>
      <h2>ব্যৱহাৰকাৰী চকু ভৰাই চাওক</h2>
      <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(220px, 1fr))", gap:16}}>
        {users.map(u=> (
          <div key={u.id} style={{border:"1px solid #ddd", padding:12, borderRadius:8}}>
            <h3>{u.name}</h3>
            <p>{u.city}</p>
            <p style={{fontSize:14, opacity:.8}}>{u.bio}</p>
            <button onClick={()=>like(u.id)}>পছন্দ</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App(){
  const { token, setToken } = useAuth();
  const [tab, setTab] = useState("register");
  if(!token){
    return (
      <div>
        <nav style={{display:"flex", gap:12, padding:12, borderBottom:"1px solid #eee"}}>
          <button onClick={()=>setTab("register")}>নিবন্ধন</button>
          <button onClick={()=>setTab("login")}>লগইন</button>
        </nav>
        {tab==="register" ? <Register /> : <Login setToken={setToken} />}
      </div>
    );
  }
  return (
    <div>
      <nav style={{display:"flex", gap:12, padding:12, borderBottom:"1px solid #eee"}}>
        <b>AxomDate</b>
        <button onClick={()=>setTab("browse")}>ব্ৰাউজ</button>
        <button onClick={()=>setTab("profile")}>প্ৰ'ফাইল</button>
        <button onClick={()=>{ setToken(""); }}>লগ-আউট</button>
      </nav>
      {tab==="browse" && <Browse token={token} />}
      {tab==="profile" && <Profile token={token} />}
      {!["browse","profile"].includes(tab) && <Browse token={token} />}
    </div>
  );
}
