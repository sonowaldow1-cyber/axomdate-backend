
# AxomDate — অসমীয়াত ডেটিং ৱেবছাইট (Starter Kit)

এই ষ্টাৰ্টাৰ কিটেৰে আপুনি খুব সোনকালে **Custom Code**ৰে নিজা ডেটিং সাইট আৰম্ভ কৰিব পাৰিব।
বেকএণ্ড: **Node.js + Express + SQLite + JWT**  
ফ্ৰণ্টএণ্ড: **React (Vite)**

---

## ১) প্ৰয়োজনীয় Software
- Node.js (v18 বা তাতোকৈ নতুন)
- npm (Node লগতে আহে)

## ২) প্ৰজেক্ট ফোল্ডাৰ
```
axom-date-starter/
  backend/  -> API Server (Express + SQLite)
  frontend/ -> React UI (Assamese-first)
```

## ৩) Backend চলাওক
```bash
cd backend
cp .env.example .env            # .env সম্পাদনা কৰক (JWT_SECRET বদলাব)
npm install
npm run init:db                 # SQLite টেবুল বনাব
npm run dev                     # http://localhost:5050
```

## ৪) Frontend চলাওক
```bash
cd frontend
npm install
npm run dev                     # http://localhost:5173
```
**মন কৰিব:** Frontend এ ডিফ'ল্টে API = `http://localhost:5050` ধৰি লয়। Production তে `VITE_API` env ভেৰিয়েব্’ল ব্যৱহাৰ কৰিব পাৰি।

## ৫) লগইন/নিবন্ধন
- `/api/auth/register` → নাম, ই-মেইল, পাছৱৰ্ড
- `/api/auth/login` → টোকেন পায় (JWT)
- টোকেনে সুৰক্ষিত এণ্ডপইণ্টসমূহ:
  - `/api/profile/me`
  - `/api/profile/update`
  - `/api/browse`
  - `/api/like/:id`
  - `/api/matches`
  - `/api/messages/:userId` (GET/POST)

## ৬) ফটো আপল'ড
- `/api/profile/photo` → form-data `photo` ফিল্ড।
- ফটো `backend/uploads/` ত সংৰক্ষণ হয়।

## ৭) পৰৱৰ্তী কাম (Roadmap)
- ✅ Basic auth, profile, browse, like/match
- 🔒 Photo moderation/verification
- 🧠 Smart matching (interests, age/location filters)
- 💬 Live chat (WebSocket)
- 💳 Membership/Subscription
- 🌐 Assamese + English i18n

## ৮) নিরাপত্তা/প্ৰডাকশ্যন টিপ্‌ছ
- শক্তিশালী `JWT_SECRET` ব্যৱহাৰ কৰক
- Rate limiting, helmet, input validation যোগ কৰক
- Reverse proxy (Nginx) আৰু HTTPS
- Cloud object storage (S3) ত ফটো সংৰক্ষণ

**শুভেচ্ছা!** কোনো সমস্যা হলে মোক ক'ব।
