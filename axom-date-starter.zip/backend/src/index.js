import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import authRouter from "./routes/auth.js";
import profileRouter from "./routes/profile.js";
import matchRouter from "./routes/match.js";
import chatRouter from "./routes/chat.js";
import { ensureDataDir, db } from "./lib/db.js";

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

ensureDataDir();

const app = express();
app.use(cors({
  origin: process.env.ALLOWED_ORIGIN?.split(",") || "*",
  credentials: true
}));
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

app.get("/", (req, res)=> res.json({ok:true, service:"AxomDate API"}));

app.use("/api/auth", authRouter);
app.use("/api/profile", profileRouter);
app.use("/api", matchRouter);
app.use("/api", chatRouter);

// Health check
app.get("/health", (req,res)=> res.json({status:"ok"}));

const PORT = process.env.PORT || 5050;
app.listen(PORT, ()=> {
  console.log(`API running on http://localhost:${PORT}`);
});
