import { Router } from "express";
import multer from "multer";
import path from "path";
import { authRequired } from "../middleware/auth.js";
import { get, all, run } from "../lib/db.js";

const router = Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(process.cwd(), "backend", "uploads"));
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + "-" + file.originalname);
  }
});
const upload = multer({ storage });

router.get("/me", authRequired, async (req, res)=>{
  const user = await get("SELECT id, name, email, gender, dob, bio, city FROM users WHERE id = ?", [req.user.id]);
  const photos = await all("SELECT id, url FROM photos WHERE user_id = ?", [req.user.id]);
  res.json({ user, photos });
});

router.post("/update", authRequired, async (req, res)=>{
  const { name, gender, dob, bio, city } = req.body;
  await run("UPDATE users SET name = ?, gender = ?, dob = ?, bio = ?, city = ? WHERE id = ?",
    [name, gender, dob, bio, city, req.user.id]);
  const user = await get("SELECT id, name, email, gender, dob, bio, city FROM users WHERE id = ?", [req.user.id]);
  res.json({ user });
});

router.post("/photo", authRequired, upload.single("photo"), async (req, res)=>{
  const rel = "/uploads/" + req.file.filename;
  await run("INSERT INTO photos (user_id, url) VALUES (?, ?)", [req.user.id, rel]);
  res.json({ url: rel });
});

export default router;
