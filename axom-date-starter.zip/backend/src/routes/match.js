import { Router } from "express";
import { authRequired } from "../middleware/auth.js";
import { all, run } from "../lib/db.js";

const router = Router();

router.get("/browse", authRequired, async (req, res)=>{
  // Simple browse: show other users (no smart matching yet)
  const rows = await all("SELECT id, name, gender, city, bio FROM users WHERE id != ? ORDER BY id DESC LIMIT 50", [req.user.id]);
  res.json({ users: rows });
});

router.post("/like/:id", authRequired, async (req, res)=>{
  const toId = parseInt(req.params.id, 10);
  await run("INSERT OR IGNORE INTO likes (from_user, to_user) VALUES (?,?)", [req.user.id, toId]);
  // Check mutual like
  const mutual = await all("SELECT 1 FROM likes WHERE from_user = ? AND to_user = ?", [toId, req.user.id]);
  res.json({ liked: true, matched: mutual.length > 0 });
});

router.get("/matches", authRequired, async (req, res)=>{
  const rows = await all(`
    SELECT u.id, u.name, u.city, u.bio
    FROM likes l1
    JOIN likes l2 ON l1.to_user = l2.from_user AND l2.to_user = l1.from_user
    JOIN users u ON u.id = l1.to_user
    WHERE l1.from_user = ?
    GROUP BY u.id
    ORDER BY u.id DESC
  `, [req.user.id]);
  res.json({ matches: rows });
});

export default router;
