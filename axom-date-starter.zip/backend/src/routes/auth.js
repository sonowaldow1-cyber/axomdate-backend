import { Router } from "express";
import { run, get } from "../lib/db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const router = Router();

router.post("/register", async (req, res)=>{
  const { name, email, password } = req.body;
  if(!name || !email || !password) return res.status(400).json({error:"Missing fields"});
  const password_hash = await bcrypt.hash(password, 10);
  try{
    const result = await run(
      "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
      [name, email, password_hash]
    );
    const user = await get("SELECT id, name, email FROM users WHERE id = ?", [result.id]);
    res.json({ user });
  }catch(e){
    res.status(400).json({error:"Email already used?"});
  }
});

router.post("/login", async (req, res)=>{
  const { email, password } = req.body;
  const user = await get("SELECT * FROM users WHERE email = ?", [email]);
  if(!user) return res.status(401).json({error:"Invalid credentials"});
  const ok = await bcrypt.compare(password, user.password_hash);
  if(!ok) return res.status(401).json({error:"Invalid credentials"});
  const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: "7d" });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

export default router;
