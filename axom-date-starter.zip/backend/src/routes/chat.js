import { Router } from "express";
import { authRequired } from "../middleware/auth.js";
import { all, run } from "../lib/db.js";

const router = Router();

router.get("/messages/:userId", authRequired, async (req, res)=>{
  const userId = parseInt(req.params.userId, 10);
  const rows = await all(`
    SELECT * FROM messages 
    WHERE (from_user = ? AND to_user = ?)
       OR (from_user = ? AND to_user = ?)
    ORDER BY id ASC
  `, [req.user.id, userId, userId, req.user.id]);
  res.json({ messages: rows });
});

router.post("/messages/:userId", authRequired, async (req, res)=>{
  const userId = parseInt(req.params.userId, 10);
  const { body } = req.body;
  if(!body) return res.status(400).json({error:"Empty message"});
  const result = await run("INSERT INTO messages (from_user, to_user, body) VALUES (?, ?, ?)", [req.user.id, userId, body]);
  res.json({ sent: true, id: result.id });
});

export default router;
